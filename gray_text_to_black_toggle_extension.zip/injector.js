const observer = new MutationObserver(() => {
  document.querySelectorAll('*').forEach(el => {
    const style = getComputedStyle(el);
    const color = style.color;
    if (color.match(/gray|rgb\((\s*1?[0-9]{1,2},){2}\s*1?[0-9]{1,2}\)/i)) {
      el.style.color = 'black';
    }
  });
});

observer.observe(document.body, {
  childList: true,
  subtree: true,
  attributes: true
});

window.__grayFixObserver__ = observer;
