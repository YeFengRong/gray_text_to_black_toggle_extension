let isActive = false;

chrome.action.onClicked.addListener((tab) => {
  isActive = !isActive;

  if (isActive) {
    chrome.scripting.insertCSS({
      target: { tabId: tab.id },
      css: "* { color: black !important; }"
    });

    chrome.scripting.executeScript({
      target: { tabId: tab.id },
      files: ["injector.js"]
    });
  } else {
    chrome.scripting.removeCSS({
      target: { tabId: tab.id },
      css: "* { color: black !important; }"
    });

    chrome.scripting.executeScript({
      target: { tabId: tab.id },
      func: () => {
        const observer = window.__grayFixObserver__;
        if (observer) observer.disconnect();
        document.querySelectorAll('*').forEach(el => {
          el.style.color = '';
        });
      }
    });
  }
});

chrome.tabs.onUpdated.addListener((tabId, changeInfo, tab) => {
  if (isActive && changeInfo.status === 'complete') {
    chrome.scripting.insertCSS({
      target: { tabId: tabId },
      css: "* { color: black !important; }"
    });

    chrome.scripting.executeScript({
      target: { tabId: tabId },
      files: ["injector.js"]
    });
  }
});
